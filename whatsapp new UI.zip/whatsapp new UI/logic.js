// Created by HARSHIL 

const followMe = () => {
    alert("Follow Me and comment your name, to see your profile here...")
  }
  
  const comment = () => {
      alert(`This feature is not added yet.
  Please comment, I will surely priortize it...`)
  }