//created by Harshil
alert("I am trying to make a simple drawing software.It is still in progress.\n    Any ideas or hints or tips in comments would be aprecciated.Thanks!")


alert("To start drawing first choose drawing tool:")

//uzimanje pocetnih vrijednosti
let isDrawing =false;
let isPencil =false;
let isErasing=false;
let isNib=false;
let lineWidth =1;
let isSize=false;
let eraseSize=10;
let selectedColor="black";
//dodavanje listenera za divove i butone
document.addEventListener("DOMContentLoaded", () => {
//kanvas
  const canvas = document.getElementById("draw-area");
  canvas.width = window.innerWidth-5;
  const ctx = canvas.getContext("2d");
  
  const pencilSizeSlider = document.getElementById("pencil-size");
   const pencilSizeValue = document.getElementById("pencil-size-value");
   const sizeDiv=document.getElementById ("slider");
   const colorDiv= document.getElementById("colord"); 
   const colorPicker = document.getElementById("color-picker");
  
  let pencil=document.getElementById ("pencil");
  let eraser=document.getElementById ("eraser");
  let nib=document.getElementById ("nib");
  

  canvas.addEventListener("mousedown", startDrawing);
  canvas.addEventListener("mousemove", draw);
  canvas.addEventListener("mouseup", stopDrawing);
  canvas.addEventListener("mouseout", stopDrawing);
  canvas.addEventListener("touchstart", startDrawing);
  canvas.addEventListener("touchmove", draw);
  canvas.addEventListener("touchend", stopDrawing);




pencilSizeSlider.addEventListener("input", function() {
  pencilSizeValue.textContent = this.value;
  
  lineWidth =parseInt(this.value);
  eraseSize =parseInt(this.value * 4);
});

colorDiv.addEventListener("click", function() { 
colorPicker .click();
 });
 
 colorPicker.addEventListener("input", function() { 
 selectedColor = colorPicker.value;
 colorDiv .style.backgroundColor=selectedColor;
  });



  document.getElementById("clear-button").addEventListener("click", clearCanvas);
  document.getElementById ("pencil").addEventListener ("click",function (){
      pencilT (this,"drawing",eraser,nib);
      
      
  });
document.getElementById("eraser").addEventListener ("click",function(){
pencilT (this,"erasing",pencil,nib);


    
});

nib.addEventListener ("click",function (){
   pencilT  (this,"nib",pencil,eraser)
   
})


  function startDrawing(e) {
    if(isDrawing || isErasing ||isNib){
        ctx.beginPath();
    ctx.moveTo(getX(e), getY(e));
    }
    
  }

  function draw(e) {
    if (!isDrawing && !isErasing&&!isNib){
    
     return;
     }
    if(isDrawing){
        ctx.lineTo(getX(e), getY(e));
        ctx.lineWidth =lineWidth;
        ctx.globalAlpha =1;
         ctx.stroke();
         ctx.strokeStyle=selectedColor;
    }else if(isErasing ){
        ctx.clearRect(getX(e),getY(e),eraseSize ,eraseSize );
    }else if(isNib){
    
         ctx.lineTo(getX(e), getY(e));
         ctx.stroke();
         ctx.globalAlpha=0.01;
         ctx.lineWidth =lineWidth;
         ctx.strokeStyle =selectedColor;
    }
    
  }

  function stopDrawing() {
    
  }

  function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  }

  function getX(e) {
    const rect = canvas.getBoundingClientRect();
    if (e.touches) {
      return e.touches[0].clientX - rect.left;
    } else {
      return e.clientX - rect.left;
    }
  }

  function getY(e) {
    const rect = canvas.getBoundingClientRect();
    if (e.touches) {
      return e.touches[0].clientY - rect.top;
    } else {
      return e.clientY - rect.top;
    }
  }
  
  function pencilT(pen, toolType,secTool,thirdTool) {
  
  
  if (toolType === 'drawing') {
    isDrawing = !isDrawing;
    isErasing = false;
    isNib =false;
    if(isDrawing ){
        pen.style.border="2px solid black";
        isSize =true;
        showSize (sizeDiv ,isSize );
        
    }else{
        pen.style.border="none";
        isSize =false;
        showSize (sizeDiv ,isSize );
        
    }

    secTool.style.border ="none";
    thirdTool .style.border="none";
    
    
    
  } else if (toolType === 'erasing') {
    isErasing = !isErasing;
    isDrawing = false;
    isNib =false;
    if(isErasing  ){
        pen.style.border="2px solid black";
        isSize =true;
        showSize (sizeDiv ,isSize );
        
    }else{
        pen.style.border="none";
        isSize =false;
        showSize (sizeDiv ,isSize );
        
    }
    secTool.style.border ="none";
    nib.style.border="none";
    
    
    
  }else if (toolType === 'nib') {
    isNib  = !isNib;
    isErasing =false;
    isDrawing = false;
    if(isNib ){
        pen.style.border="2px solid black";
        isSize =true;
        showSize (sizeDiv ,isSize );
        
    }else{
        pen.style.border="none";
        isSize =false;
        showSize (sizeDiv ,isSize );
        
    }
    secTool.style.border ="none";
    thirdTool .style .border ="none";
    
    
  }
  
 
  
}

function showSize(size,isSize){
if(isSize){
    size.style.display="flex";
}else{
    size.style.display="none";
}
    
}




});
