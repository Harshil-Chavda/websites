// breakpoints
var BREAK = {
    LG: 1024,
    MD: 980,
    SM: 768,
    VS: 480,
    MN_L: 568,
    MN: 320
};