// Created by Мг. Кнап🌠 

alert("        ***Updates***\n\n1. Changed Color Scheme.\n2. Changed Flow Layout\n3. Made Responsive Rows");